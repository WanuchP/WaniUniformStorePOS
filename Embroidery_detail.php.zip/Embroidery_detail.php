<!DOCTYPE html>
<html>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inria+Sans&display=swap');
      </style>
<head>
    <meta charset="UTF-8">
    <title>Embroidery detail desktop</title>
    <link rel="stylesheet" href="styles_emb_detail.css">
</head>
<body style="background-color:#F2F2F2;">
    <div class="user-container">
        <div style="margin-top: auto;"> User: cashier1</div>
     </div>
        <div class="embroidery-details" >Embroidery details</div>
        <div class="student-shirt">Student shirt3</div>
        <div class="instruction">Blank is do not embroidery</div>
    <form >
       
        <table >
            <tr>
                <th></th>
                <th></th>
                <th><div style="display: flexbox; width: 200px;">Position</div></th>
                <th>Color</th>
              </tr>
            <tr>
              <th>Name in Thai:</th>
              <th><div style="display: flexbox; width: 350px;"><input class="box1"></div></th>
              <th><select class="select1">Position
                <option value="volvo">Volvo</option>
                <option value="saab">Saab</option>
                <option value="fiat">Fiat</option>
                <option value="audi">Audi</option>
              </select></th>
              <th><select class="select1">Position
                <option value="volvo">Volvo</option>
                <option value="saab">Saab</option>
                <option value="fiat">Fiat</option>
                <option value="audi">Audi</option>
              </select></th>
            </tr>
            <tr>
                <th>Name in English: </th>
                <th><div><input class="box1"></div></th>
                <th><select class="select1">Position
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="fiat">Fiat</option>
                  <option value="audi">Audi</option>
                </select></th>
                <th><select class="select1">Position
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="fiat">Fiat</option>
                  <option value="audi">Audi</option>
                </select></th>
            </tr>
            <tr>
                <th>School: </th>
              <th><div style="display: flexbox; width: 350px;"><input class="box1"></div></th>
              <th><div style="display: flexbox; font-size: 12px;">*ใส่ชื่อโรงเรียนเพื่อเป็นข้อมูลเท่านั้น ไม่ใช่รายละเอียดการปัก</div></th>
            </tr>
            <tr>
                <th>School acronym:</th>
                <th><div style="display: flexbox; width: 350px;"><input class="box1"></div></th>
                <th><select class="select1">Position
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="fiat">Fiat</option>
                  <option value="audi">Audi</option>
                </select></th>
                <th><select class="select1">Position
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="fiat">Fiat</option>
                  <option value="audi">Audi</option>
                </select></th>
              </tr>
              <tr>
                  <th>School logo: </th>
                  <th>
                  <div class="tick">
                    <input type="checkbox">
                    <label for="School-logo"> Yes</label><br>
                    <input type="checkbox">
                    <label for="School-logo"> No</label><br>
                  </div>
                </th>
                <th><select class="select1">Position
                    <option value="volvo">Volvo</option>
                    <option value="saab">Saab</option>
                    <option value="fiat">Fiat</option>
                    <option value="audi">Audi</option>
                  </select></th>
              </tr>
              <tr>
                <th>Student ID:  </th>
                <th><div><input class="box1"></div></th>
                <th><select class="select1">Position
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="fiat">Fiat</option>
                  <option value="audi">Audi</option>
                </select></th>
                <th><select class="select1">Position
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="fiat">Fiat</option>
                  <option value="audi">Audi</option>
                </select></th>
            </tr>
            <tr>
                <th>Class symbol: </th>
                <th>
                <div class="tick">
                  <input type="checkbox">
                  <label for="School-logo"> Dot</label><br>
                  <input type="checkbox">
                  <label for="school-logo"> Star</label><br>
                  <label>Other: </label>
                  <input class="box2">
                  <label style="margin-left: auto;">No. </label>
                  <input class="box2">
                </div>
              </th>
              <th><select class="select1">Position
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="fiat">Fiat</option>
                  <option value="audi">Audi</option>
                </select></th>
                <th><select class="select1">Position
                    <option value="volvo">Volvo</option>
                    <option value="saab">Saab</option>
                    <option value="fiat">Fiat</option>
                    <option value="audi">Audi</option>
                  </select></th>
            </tr>

          </table>
    </form>
    <div class="bottom_line">
    <button type="button" class="button1" onclick="window.location.href='embroidery_desktop.php'">
      <div><img src="icon _arrow left 1_.png" style="width: 25px;"></div>
      <div>Return</div>
    </button>
    <button type="button" class="button2" onclick="window.location.href='embroidery_desktop.php'">
      <div>Complete</div>
      <div><img src="icon _arrow right 1_.png" style="width: 25px;"></div>
    </button>
  </div>



</body>
</html>